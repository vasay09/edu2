package edu;

import java.io.IOException;

// Generic type for any implementation of key object
public interface Keys {

    public String publicKey();

    public String secretKey();

}
